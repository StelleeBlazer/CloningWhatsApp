package com.example.whatclone.listener

interface ContactClickListener {
    fun onContactCliceked(name: String?, phone: String?)
}
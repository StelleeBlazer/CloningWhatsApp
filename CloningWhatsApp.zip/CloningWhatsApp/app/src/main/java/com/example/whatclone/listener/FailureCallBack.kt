package com.example.whatclone.listener

interface FailureCallBack {
    fun onUserError()
}